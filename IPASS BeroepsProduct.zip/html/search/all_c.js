var searchData=
[
  ['selectcard',['selectCard',['../classrc522.html#a5016ad241df63301c261709debcb274b',1,'rc522']]],
  ['selftest',['selfTest',['../classrc522.html#ae2b0fd03ac296593e4b031a0308e3233',1,'rc522']]],
  ['setmostfromarrayuint',['setMostFromArrayUint',['../classsheet.html#a64845c424dc2e36b3d8268cac104d4b3',1,'sheet']]],
  ['setnamefromarrayuint',['setNameFromArrayUint',['../classsheet.html#a3d9fc4c4f4cdd28f6d9accffb0037136',1,'sheet']]],
  ['setregbitmask',['setRegBitMask',['../classrc522.html#a2a6643f07cb56370ce58605b4aa4bde1',1,'rc522::setRegBitMask(rc522::commands regAddr, uint8_t mask)'],['../classrc522.html#acadff61e3733655710ea945c03137a39',1,'rc522::setRegBitMask(rc522::registers regAddr, uint8_t mask)'],['../classrc522.html#aae350dcb495ec47cbb081b2fd9df35ff',1,'rc522::setRegBitMask(rc522::configuration regAddr, uint8_t mask)'],['../classrc522.html#ac3752c747cd1cbb4510eaf24d363befe',1,'rc522::setRegBitMask(rc522::test regAddr, uint8_t mask)']]],
  ['sheet',['sheet',['../classsheet.html',1,'sheet'],['../classsheet.html#afae0c2b257d19526ca0482e3e246ec30',1,'sheet::sheet()']]],
  ['softreset',['softReset',['../classrc522.html#a60bfe75989ff8f654d412d7802993a53',1,'rc522']]],
  ['spibus',['spiBus',['../classspiReader.html#adb87e7c8ca2a11337b67fe8efce50262',1,'spiReader']]],
  ['spireader',['spiReader',['../classspiReader.html',1,'spiReader'],['../classspiReader.html#af8eca236eb5cfe4e806f0151227e42b4',1,'spiReader::spiReader()']]],
  ['status',['status',['../classspiReader.html#a4bcf984823c38cf4841ebf619e788790',1,'spiReader']]],
  ['stopcrypto',['stopCrypto',['../classrc522.html#a0f15a1c190dcde40f314ff4f6ffb65e4',1,'rc522']]]
];
