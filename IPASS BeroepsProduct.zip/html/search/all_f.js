var searchData=
[
  ['wakecard',['wakeCard',['../classrc522.html#a998688cd59ae05add31c7c6847bf02ae',1,'rc522']]],
  ['writeblock',['writeBlock',['../classrc522.html#ae660e16f131e5a28a4412b26d1f016a0',1,'rc522']]],
  ['writereg',['writeReg',['../classrc522.html#a3045ab844b8de82e9a5f3504c82c8995',1,'rc522::writeReg(rc522::commands regAddr, uint8_t data)'],['../classrc522.html#aa8e748a997e22ef74e00c05f8d8383c5',1,'rc522::writeReg(rc522::registers regAddr, uint8_t data)'],['../classrc522.html#a51979eca697dcfeddf2ef8795adf7851',1,'rc522::writeReg(rc522::configuration regAddr, uint8_t data)'],['../classrc522.html#a6907bf656f821a89e636a1b8cf28fe60',1,'rc522::writeReg(rc522::test regAddr, uint8_t data)'],['../classrc522.html#a458e303b33f57ed839c21e790f912191',1,'rc522::writeReg(rc522::registers regAddr, rc522::regCommands data)'],['../classrc522.html#adce878aa570ff9f611df399139229265',1,'rc522::writeReg(rc522::registers regAddr, std::array&lt; uint8_t, N &gt; data)']]],
  ['writesheettocard',['writeSheetToCard',['../classrc522.html#a69f4af5f03ac07d17918880e4f9e09c3',1,'rc522']]]
];
