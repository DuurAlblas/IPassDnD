var searchData=
[
  ['uid',['uid',['../classmifare_1_1card.html#a0f97900bf64b956ac9f9622671aa4f74',1,'mifare::card']]],
  ['unsetregbitmask',['unsetRegBitMask',['../classrc522.html#a18c7a632fbb1206326008025c522ef20',1,'rc522::unsetRegBitMask(rc522::commands regAddr, uint8_t mask)'],['../classrc522.html#ad5a055b560cb7e84801497a6acad1e70',1,'rc522::unsetRegBitMask(rc522::registers regAddr, uint8_t mask)'],['../classrc522.html#a1ebf4ec7b5342e683310f526a1f10ede',1,'rc522::unsetRegBitMask(rc522::configuration regAddr, uint8_t mask)'],['../classrc522.html#a52f345b15adb65750491a0bc4ccc7513',1,'rc522::unsetRegBitMask(rc522::test regAddr, uint8_t mask)']]]
];
