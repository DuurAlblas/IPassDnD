var searchData=
[
  ['initialize',['initialize',['../classrc522.html#a49a6b70c2d43ae0d22c608025ac55dec',1,'rc522']]]
];
