var searchData=
[
  ['antennaoff',['antennaOff',['../classrc522.html#a3318612b0a93b415415ef9e1a6b03dae',1,'rc522']]],
  ['antennaon',['antennaOn',['../classrc522.html#a9f2477eaf7d1f2f3123714cce6311d62',1,'rc522']]],
  ['authenticatecard',['authenticateCard',['../classrc522.html#a9cba68c4fff6e1acf8bf9b2601197d96',1,'rc522']]]
];
