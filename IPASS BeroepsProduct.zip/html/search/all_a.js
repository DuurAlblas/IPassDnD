var searchData=
[
  ['printall',['printAll',['../classsheet.html#a9689c670d509517bfe17c1b8941aaaaf',1,'sheet']]],
  ['printallignment',['printAllignment',['../classsheet.html#aa0e0036c9943ca69c4e05e0a1c03b1e7',1,'sheet']]],
  ['printlanguage',['printLanguage',['../classsheet.html#a52a971ba4d8131fec3c5d13fd27cf692',1,'sheet']]],
  ['printname',['printName',['../classsheet.html#a39028f2eb082d2b50bfa05873767de52',1,'sheet']]],
  ['printprofesion',['printProfesion',['../classsheet.html#aeaee0f027d25a9076ebabad9bcb51a40',1,'sheet']]],
  ['printrace',['printRace',['../classsheet.html#a84f442ba9c1fe19f04bc1e8eed30c8c4',1,'sheet']]]
];
