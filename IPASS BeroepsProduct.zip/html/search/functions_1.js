var searchData=
[
  ['calccrc',['calcCRC',['../classrc522.html#a6d3fe62ea90de72aa783331cf21f54fe',1,'rc522']]],
  ['card',['card',['../classmifare_1_1card.html#add87ee9228a95ef57e6778e837a5fa68',1,'mifare::card::card(std::array&lt; uint8_t, 4 &gt; uid, std::array&lt; uint8_t, 6 &gt; keyA, std::array&lt; uint8_t, 6 &gt; keyB, uint8_t maxBlocks)'],['../classmifare_1_1card.html#aff06c5ecc67800474ee8f3e76d4bf1f4',1,'mifare::card::card()']]],
  ['cardcommunication',['cardCommunication',['../classrc522.html#a4034678819a3442934c55ba5c2f2588d',1,'rc522']]],
  ['cardtransceive',['cardTransceive',['../classrc522.html#adcad63b7a87430ae943c833bcd9e24ab',1,'rc522::cardTransceive(std::array&lt; uint8_t, N1 &gt; &amp;bufSend, std::array&lt; uint8_t, N2 &gt; &amp;bufReceive, uint8_t bitFraming=0, bool checkCrc=false)'],['../classrc522.html#a4aa6f24387944a7aee98398dd300b7a0',1,'rc522::cardTransceive(std::array&lt; mifare::command, N1 &gt; &amp;bufComData, std::array&lt; uint8_t, N2 &gt; &amp;bufReceive, uint8_t bitFraming=0, bool checkCrc=false)']]],
  ['compareversion',['compareVersion',['../classrc522.html#a144c7bf4db9385aaa345c40f36ec929c',1,'rc522']]]
];
