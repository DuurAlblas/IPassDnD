var searchData=
[
  ['commands',['commands',['../classrc522.html#a6df2359c88d6c2f47faf58bc9e09eaa4',1,'rc522']]],
  ['configuration',['configuration',['../classrc522.html#afcf27c8198d017cd4e8173c7d7a6fded',1,'rc522']]]
];
