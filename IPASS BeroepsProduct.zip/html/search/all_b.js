var searchData=
[
  ['rc522',['rc522',['../classrc522.html',1,'rc522'],['../classrc522.html#a7f123bdc20d19e897c883ec12f1f0849',1,'rc522::rc522()']]],
  ['readblock',['readBlock',['../classrc522.html#a87dfbf9cf9707a675c91981c92c93fdc',1,'rc522']]],
  ['readreg',['readReg',['../classrc522.html#a98c225391f24da6a963e67b5e89f96be',1,'rc522::readReg(rc522::commands regAddr)'],['../classrc522.html#a9398f2a0effc1a0acd48735d7d014c6e',1,'rc522::readReg(rc522::registers regAddr)'],['../classrc522.html#a96857ef5f6e2a9b4bc7e6901f65907b5',1,'rc522::readReg(rc522::configuration regAddr)'],['../classrc522.html#a1b5a8b96bae53a3832e10054211f5064',1,'rc522::readReg(rc522::test regAddr)']]],
  ['readsheetfromcard',['readSheetFromCard',['../classrc522.html#ad265d81264eecf2124ad224c89d6c8e7',1,'rc522']]],
  ['regcommands',['regCommands',['../classrc522.html#a3a205976fb9b7265bc5b7971215fbb7c',1,'rc522']]],
  ['registers',['registers',['../classrc522.html#a83057db5f8fefa3dc9a6e8e5f0e191ee',1,'rc522']]]
];
