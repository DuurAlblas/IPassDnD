var searchData=
[
  ['status',['status',['../classspiReader.html#a4bcf984823c38cf4841ebf619e788790',1,'spiReader']]]
];
