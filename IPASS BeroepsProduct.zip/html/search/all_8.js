var searchData=
[
  ['maxblocks',['maxBlocks',['../classmifare_1_1card.html#a3283a205a271075bd6e4b0bea3f015cb',1,'mifare::card']]]
];
