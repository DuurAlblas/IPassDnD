var searchData=
[
  ['uid',['uid',['../classmifare_1_1card.html#a0f97900bf64b956ac9f9622671aa4f74',1,'mifare::card']]]
];
