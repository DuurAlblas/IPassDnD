var searchData=
[
  ['keya',['keyA',['../classmifare_1_1card.html#a9d6bb609c82ca6fa65a79e83656db964',1,'mifare::card']]],
  ['keyb',['keyB',['../classmifare_1_1card.html#ae99191bf1a9478b61f4b0043c6e0d7bf',1,'mifare::card']]]
];
