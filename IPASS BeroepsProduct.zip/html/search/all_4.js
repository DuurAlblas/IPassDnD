var searchData=
[
  ['getmosttoarrayuint',['getMostToArrayUint',['../classsheet.html#a4a9a029a5e816b0c4cb75441f231e2de',1,'sheet']]],
  ['getnametoarrayuint',['getNameToArrayUint',['../classsheet.html#a83692af2c0ec0962a3c92e679a8f8648',1,'sheet']]]
];
