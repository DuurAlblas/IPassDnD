var searchData=
[
  ['executeread',['executeRead',['../classrc522.html#aa0eeb1eedf5ca47a44cab85a387156f3',1,'rc522']]],
  ['executewrite',['executeWrite',['../classrc522.html#adab984cd49ca9affb679dded266c43f0',1,'rc522']]]
];
