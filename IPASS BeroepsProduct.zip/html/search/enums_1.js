var searchData=
[
  ['regcommands',['regCommands',['../classrc522.html#a3a205976fb9b7265bc5b7971215fbb7c',1,'rc522']]],
  ['registers',['registers',['../classrc522.html#a83057db5f8fefa3dc9a6e8e5f0e191ee',1,'rc522']]]
];
