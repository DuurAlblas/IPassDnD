var searchData=
[
  ['nss',['nss',['../classspiReader.html#a2a241a80ce921c4df38b3080d839850f',1,'spiReader']]]
];
